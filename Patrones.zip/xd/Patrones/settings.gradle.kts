rootProject.name = "Patrones"
include("singleton")
include("factory")
include("ejercicioFactoryBasico")


include("AbstractFactory")
include("Builder")