package com.impl;

import com.inter.IDisneyMovie;

public class DisneyComedyMovie implements IDisneyMovie {

    @Override
    public String movieName() {
        return "Disney: Piratas del Caribe";
    }
}
