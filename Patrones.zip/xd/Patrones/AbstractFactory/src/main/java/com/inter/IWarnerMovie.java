package com.inter;

public interface IWarnerMovie {
    String movieName();
}
