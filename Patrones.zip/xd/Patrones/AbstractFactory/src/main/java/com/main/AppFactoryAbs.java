package com.main;

import com.impl.ActionMovieFactory;
import com.impl.ComedyMovieFactory;
import com.inter.IDisneyMovie;
import com.inter.IWarnerMovie;

public class AppFactoryAbs {

    public static void main(String[] args) {
        ActionMovieFactory actionFactory = new ActionMovieFactory();
        ComedyMovieFactory comedyFactory = new ComedyMovieFactory();

        System.out.println("----Peliclas de accion disponibles----");
        IDisneyMovie dAct = actionFactory.getDisneyMovie();
        IWarnerMovie wAct = actionFactory.getWarnerMovie();
        System.out.println(dAct.movieName() + "\n" + wAct.movieName());

        System.out.println("----Peliclas de comedia disponibles----");
        IWarnerMovie wCom = comedyFactory.getWarnerMovie();
        IDisneyMovie dCom = comedyFactory.getDisneyMovie();
        System.out.println(wCom.movieName() + "\n" + dCom.movieName());

    }
}
