package com.impl;

import com.inter.IDisneyMovie;

public class DisneyActionMovie implements IDisneyMovie {

    @Override
    public String movieName() {
        return "Disney: Mulan";
    }

}
