package com.impl;

import com.inter.IDisneyMovie;
import com.inter.IMovieFactory;
import com.inter.IWarnerMovie;

public class ActionMovieFactory implements IMovieFactory {
    @Override
    public IWarnerMovie getWarnerMovie() {
        return new WarnerActionMovie();
    }

    @Override
    public IDisneyMovie getDisneyMovie() {
        return new DisneyActionMovie();
    }
}
