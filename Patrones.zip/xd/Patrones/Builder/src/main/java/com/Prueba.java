package com;

import lombok.*;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class Prueba {
    private String name;
    private int val;
    private double valor;
    private String tipo;
}
