package com;

import dos.com.Libro;

public class App {
    Prueba p= Prueba.builder().name("Ana").valor(7).tipo("Prueba").valor(14.3).build();

    Libro libro = Libro.builder().build();
}
