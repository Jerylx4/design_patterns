package com.implementaciones;

import com.interfaces.IProductos;

public class Cuadros implements IProductos {
}
