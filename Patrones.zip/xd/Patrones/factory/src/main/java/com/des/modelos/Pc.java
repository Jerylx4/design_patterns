package com.des.modelos;

import com.des.anotaciones.MiComponente;

@MiComponente(name = "pc")
public class Pc implements Computadoras {
    {
    System.out.println("pc asdasdasdasd");
    }

//    private String marca;
//    private String modelo;
//    private String procesador;
//    private int memoriaRAM;
//    private int almacenamiento;
//    private String tipoGabinete;
//    private boolean tieneTarjetaVideo;
//
//    public Pc(String marca, String modelo, String procesador, int memoriaRAM,
//              int almacenamiento, String tipoGabinete, boolean tieneTarjetaVideo) {
//        this.marca = marca;
//        this.modelo = modelo;
//        this.procesador = procesador;
//        this.memoriaRAM = memoriaRAM;
//        this.almacenamiento = almacenamiento;
//        this.tipoGabinete = tipoGabinete;
//        this.tieneTarjetaVideo = tieneTarjetaVideo;
    }

//    @Override
//    public void encender() {
//        System.out.println("PC encendida.");
//    }
//
//    @Override
//    public void apagar() {
//        System.out.println("PC apagada.");
//    }
//
//    @Override
//    public String getMarca() { return marca; }
//
//    @Override
//    public String getModelo() { return modelo; }
//}


