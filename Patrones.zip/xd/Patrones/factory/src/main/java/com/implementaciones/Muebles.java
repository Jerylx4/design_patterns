package com.implementaciones;

import com.interfaces.IProductos;

public class Muebles implements IProductos {
}
