package com.implementaciones;
public enum Tipos {
    Mascota,Muebles,Cuadros
}
