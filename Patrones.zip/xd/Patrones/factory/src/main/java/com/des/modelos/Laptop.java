package com.des.modelos;

import com.des.anotaciones.MiComponente;

@MiComponente(name = "laptop")
public class Laptop implements Computadoras {
    {
        System.out.println("laptop");
    }
}
