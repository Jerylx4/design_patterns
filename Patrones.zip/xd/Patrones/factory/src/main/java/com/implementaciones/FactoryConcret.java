package com.implementaciones;

import com.interfaces.IFactory;
import com.interfaces.IProductos;

public class FactoryConcret<T extends IProductos> implements IFactory<T> {
    @Override
    public T createFactory(Class<T> tipo) {
        try{
            T a = tipo.getDeclaredConstructor().newInstance();
            return a;
        }catch (Exception e) {
            throw new RuntimeException("No se pudo crear el producto: " + tipo.getName(), e);
        }
    }


//    @Override
//    public IProductos createFactory(Tipos tipo) {
//        return switch (tipo) {
//            case Cuadros -> new Cuadros();
//            case Mascota -> new Mascota();
//            case Muebles -> new Muebles();
//        };
//
//    }

}
