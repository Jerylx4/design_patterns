package com.implementaciones;

import com.interfaces.IProductos;

public class Mascota implements IProductos {
}
