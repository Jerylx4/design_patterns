package com.des.modelos;

import com.des.anotaciones.MiComponente;

@MiComponente(name = "server")
public class Server implements Computadoras{
    {
        System.out.println("server");
    }
}
