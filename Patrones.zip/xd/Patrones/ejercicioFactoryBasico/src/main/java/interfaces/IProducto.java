package interfaces;


public interface IProducto {
    void mostrarInformacion();
}

