package interfaces;

import main.TipoProducto;

public interface IFactory {
    <T> T createFactory(String name);
    void init(String pkgName);
}
