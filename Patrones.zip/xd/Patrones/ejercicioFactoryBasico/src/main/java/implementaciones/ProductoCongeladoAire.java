package implementaciones;

import anotaciones.Productos;

@Productos(name = "prdCongeladoAire")
public class ProductoCongeladoAire extends ProductoCongelado {

    private double porcentajeNitrogeno;
    private double porcentajeOxigeno;
    private double porcentajeCO2;
    private double porcentajeVaporAgua;

    public ProductoCongeladoAire(){
        super();
    }

    public ProductoCongeladoAire(String fechaCaducidad, String numeroLote, String paisOrigen,
                                 String fechaEnvasado, double temperaturaMantenimiento,
                                 double n2, double o2, double co2, double h2o) {
        super(fechaCaducidad, numeroLote, paisOrigen, fechaEnvasado, temperaturaMantenimiento);
        this.porcentajeNitrogeno = n2;
        this.porcentajeOxigeno = o2;
        this.porcentajeCO2 = co2;
        this.porcentajeVaporAgua = h2o;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Producto Congelado por Aire:");
        mostrarDatosBase();
        System.out.println("  Fecha envasado: " + fechaEnvasado);
        System.out.println("  Temp. mantenimiento: " + temperaturaMantenimiento + "°C");
        System.out.println("  Composición del aire: N2=" + porcentajeNitrogeno + "%, O2=" + porcentajeOxigeno +
                "%, CO2=" + porcentajeCO2 + "%, H2O=" + porcentajeVaporAgua + "%");
    }
}

