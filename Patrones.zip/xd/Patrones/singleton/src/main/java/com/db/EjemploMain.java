package com.db;

import com.db.modelo.Persona;

public class EjemploMain {
    public static void main(String[] args){
       // try(var con = ConexionDb.getConnection()){

       // }catch (Exception ex){
      //      ex.printStackTrace();
     //   }

        PersonaCrud personaCrud = new PersonaCrud();
        personaCrud.buscar(1)
                .ifPresentOrElse(
                //per -> System.out.println(per),
                System.out::println,
                () -> System.out.println("persona no encontrada")
        );
    }
}
