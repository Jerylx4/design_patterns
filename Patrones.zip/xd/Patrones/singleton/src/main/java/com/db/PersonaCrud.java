package com.db;

import com.db.modelo.Persona;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Optional;

public class PersonaCrud {
    public Optional<Persona> buscar(Integer id) {
        try (Connection con = ConexionDb.getConnection()) {
            String txt = "select * from personas where id=?";
            PreparedStatement pstmt = con.prepareStatement(txt);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Persona per = new Persona();
                per.setId(rs.getInt("id"));
                per.setNombre(rs.getString("nombre"));
                per.setEdad(rs.getInt("edad"));
                per.setDireccion(rs.getString("direccion"));

                return Optional.of(per);

            }
            return Optional.empty();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
