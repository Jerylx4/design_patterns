package com.modelo;

public class AutoHibrido {

    private boolean conectado;

    public AutoHibrido() {
        System.out.println("AutoHibrido creado");
        this.conectado = false;
    }

    public void conectar() {
        System.out.println("Auto Hibrido conectando bateria");
        this.conectado = true;
    }

    public void activar() {

        if (!this.conectado) {
            System.out.println("Auto Hibrido no se puede activar por que no esta conectada la bateria");

        } else {
            System.out.println("Auto Hibrido esta conectado, activando motor electrico");
        }

    }

    public void moverRapido() {
        if (!this.conectado) {
            System.out.println("Auto Hibrido esta trabajando con motor electrico");
        }else{
            System.out.println("acelerando, el motor ");
        }
    }

    public void detener() {
        if (!this.conectado) {
            System.out.println("Auto Hibrido debe desconectar primero");
        }else{
            System.out.println("deteniendo el motor");
        }
    }
    public void desconectar() {
        if (!this.conectado) {
            System.out.println("Auto Hibrido desconectando el motor electrico ");
            this.conectado= false;
        }else{
            System.out.println("motor desconectado");
        }
    }
}
