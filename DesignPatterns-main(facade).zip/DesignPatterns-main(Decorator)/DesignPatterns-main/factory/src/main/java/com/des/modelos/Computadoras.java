package com.des.modelos;

public interface Computadoras {

}

