package com.main;

import com.build.Libro;
import com.factory.IFactoryLibro;
import com.factory.LibroFactory;

public class EjemploMain {

    public static void main(String[] args) {


        IFactoryLibro factory = new LibroFactory();

        Libro libro = factory.crearLibro(
                4,
                "El Señor de los Anillos",
                "978-0261103252",
                "A100"
        );

        System.out.println(libro);
    }
}
