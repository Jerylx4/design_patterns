package com.factory;

import com.build.Libro;

public interface IFactoryLibro {
    Libro crearLibro(Integer id, String titulo, String isbn, String idAutor);

}
