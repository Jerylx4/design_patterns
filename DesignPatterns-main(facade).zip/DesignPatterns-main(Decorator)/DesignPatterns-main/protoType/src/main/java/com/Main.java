package com;

import com.imple.BYD;
import com.imple.Ford;
import com.imple.Toyota;
import com.inter.CarroBasico;

public class Main {
    public static void main(String[] args) throws Exception {

        CarroBasico carroF = new Ford("scape");
        carroF.precio = 12500;
        CarroBasico carroT = new Toyota("Cordeola");
        carroT.precio = 30000;
        CarroBasico carroB = new BYD("Ccc");
        carroB.precio = 20000;

        CarroBasico cf = carroF.clone();
        cf.precio = cf.precio +cf.setPrecio();
        CarroBasico ct = carroT.clone();
        ct.precio = ct.precio +ct.setPrecio();
        CarroBasico cB = carroB.clone();
        cB.precio = cB.precio +cB.setPrecio();

        CarroBasico cf1 = carroF.clone();
        cf1.precio = cf1.precio +cf1.setPrecio();
        CarroBasico ct1 = carroT.clone();
        ct1.precio = ct1.precio +ct1.setPrecio();
        CarroBasico cB1 = carroB.clone();
        cB1.precio = cB1.precio +cB1.setPrecio();

        CarroBasico cf2 = carroF.clone();
        cf2.precio = cf2.precio +cf2.setPrecio();
        CarroBasico ct2 = carroT.clone();
        ct2.precio = ct2.precio +ct2.setPrecio();
        CarroBasico cB2 = carroB.clone();
        cB2.precio = cB2.precio +cB2.setPrecio();

        System.out.println(carroT.toString());
        System.out.println(carroF.toString());
        System.out.println(carroB.toString());
        System.out.println();

        System.out.println(cf.toString());
        System.out.println(ct.toString());
        System.out.println(cB.toString());
        System.out.println();

        System.out.println(cf1.toString());
        System.out.println(ct1.toString());
        System.out.println(cB1.toString());
        System.out.println();

        System.out.println(cf2.toString());
        System.out.println(ct2.toString());
        System.out.println(cB2.toString());
        System.out.println();
    }
}
