package com.model;

import com.google.common.reflect.ClassPath;
import com.inter.Decorador;
import com.inter.INotificacion;

import java.util.HashMap;
import java.util.Map;

public class DecoratorLoader {

    private Map<String, Class<? extends NotificacionDecorador>> decoradores = new HashMap<>();

    public void init(String pkgName){
        try{
            ClassPath classPath = ClassPath.from(getClass().getClassLoader());
            for(ClassPath.ClassInfo classInfo : classPath.getTopLevelClassesRecursive(pkgName) ){
                Class<?> clas = classInfo.load();
                if(INotificacion.class.isAssignableFrom(clas)){
                    Decorador anotacion = clas.getAnnotation(Decorador.class);
                    if(anotacion != null){
                        decoradores.put(anotacion.value(), (Class<? extends NotificacionDecorador>) clas);
                    }
                }
            }
        }catch(Exception e){
            throw new RuntimeException("ERROR AL INICIALIZAR LOS DECORADORES" + e);
        }
    }
}
