package implementaciones;

import anotaciones.Productos;

@Productos(name = "prdCongeladoAgua")

public class ProductoCongeladoAgua extends ProductoCongelado {

    private double gramosSalPorLitro;

    public ProductoCongeladoAgua(){
        super();
    }

    public ProductoCongeladoAgua(String fechaCaducidad, String numeroLote, String paisOrigen,
                                 String fechaEnvasado, double temperaturaMantenimiento, double gramosSalPorLitro) {
        super(fechaCaducidad, numeroLote, paisOrigen, fechaEnvasado, temperaturaMantenimiento);
        this.gramosSalPorLitro = gramosSalPorLitro;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Producto Congelado por Agua:");
        mostrarDatosBase();
        System.out.println("  Fecha envasado: " + fechaEnvasado);
        System.out.println("  Temp. mantenimiento: " + temperaturaMantenimiento + "°C");
        System.out.println("  Salinidad: " + gramosSalPorLitro + " g/L");
    }
}

