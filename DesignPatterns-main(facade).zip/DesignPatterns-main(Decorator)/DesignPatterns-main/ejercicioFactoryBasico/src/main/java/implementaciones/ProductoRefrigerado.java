package implementaciones;

import anotaciones.Productos;

@Productos(name = "prdRefrigerado")
public class ProductoRefrigerado extends Producto {


    private String codigoSupervision;
    private String fechaEnvasado;
    private double temperaturaMantenimiento;


    public ProductoRefrigerado(){
        super();
    }


    public ProductoRefrigerado(String fechaCaducidad, String numeroLote, String paisOrigen,
                               String codigoSupervision, String fechaEnvasado, double temperaturaMantenimiento) {
        super(fechaCaducidad, numeroLote, paisOrigen);
        this.codigoSupervision = codigoSupervision;
        this.fechaEnvasado = fechaEnvasado;
        this.temperaturaMantenimiento = temperaturaMantenimiento;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Producto Refrigerado:");
        mostrarDatosBase();
        System.out.println("  Código supervisión: " + codigoSupervision);
        System.out.println("  Fecha envasado: " + fechaEnvasado);
        System.out.println("  Temp. mantenimiento: " + temperaturaMantenimiento + "°C");
    }
}
