package implementaciones;

public abstract class ProductoCongelado extends Producto {

    protected String fechaEnvasado;
    protected double temperaturaMantenimiento;

    public ProductoCongelado(String fechaCaducidad, String numeroLote, String paisOrigen,
                             String fechaEnvasado, double temperaturaMantenimiento) {
        super(fechaCaducidad, numeroLote, paisOrigen);
        this.fechaEnvasado = fechaEnvasado;
        this.temperaturaMantenimiento = temperaturaMantenimiento;
    }

    public ProductoCongelado() {

    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Producto Congelado:");
        mostrarDatosBase();
        System.out.println("  Fecha envasado: " + fechaEnvasado);
        System.out.println("  Temp. mantenimiento: " + temperaturaMantenimiento + "°C");
    }
}
