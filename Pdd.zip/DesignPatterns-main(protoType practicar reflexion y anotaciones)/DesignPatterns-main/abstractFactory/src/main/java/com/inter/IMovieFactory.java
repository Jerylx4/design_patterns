package com.inter;

public interface IMovieFactory {
    IWarnerMovie getWarnerMovie();
    IDisneyMovie getDisneyMovie();
}
