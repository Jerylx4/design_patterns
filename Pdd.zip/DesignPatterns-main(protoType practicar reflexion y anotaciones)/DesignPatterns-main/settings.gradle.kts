rootProject.name = "Patrones"
include("singleton")
include("factory")
include("ejercicioFactoryBasico")
include("abstractFactory")
include("builder")
include("ejercicioEnClase1")
include("protoType")
include("adapter")