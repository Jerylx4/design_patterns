package com.impl;

import com.inter.Auto;
import com.model.AutoHibrido;

public class AutoHibridoAdapter implements Auto {
    private AutoHibrido autoHibrido;

    public AutoHibridoAdapter(){
        System.out.println("Creando AutoHibrido mediante el adapter");
        this.autoHibrido= new AutoHibrido();
    }

    @Override
    public void encender() {
        System.out.println("Encendiendo AutoHibrido mediante el adapter");
        this.autoHibrido.conectar();
        this.autoHibrido.activar();
    }

    @Override
    public void acelerar() {
        System.out.println("Acelerando AutoHibrido mediante el adapter");
        this.autoHibrido.moverRapido();
    }

    @Override
    public void apagar() {
        System.out.println("Apagando AutoHibrido mediante el adapter");
        this.autoHibrido.detener();
        this.autoHibrido.desconectar();
    }
}
