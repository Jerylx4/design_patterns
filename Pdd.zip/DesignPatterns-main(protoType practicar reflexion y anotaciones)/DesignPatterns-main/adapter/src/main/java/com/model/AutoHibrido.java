package com.model;

public class AutoHibrido {
    private boolean conectado;

    public AutoHibrido() {
        System.out.println("Auto hibrido creado");
        this.conectado = false;
    }

    public void conectar(){
        System.out.println("conectando bateria/motor hibrido");
        this.conectado = true;
    }

    public void activar(){
        if(!this.conectado){
            System.out.println("No se puede activar porque no esta conectada la bateria/motor hibrido");
        }else{
            System.out.println("Esta conectado, activando bateria/motor hibrido");
        }
    }

    public void moverRapido(){
        if(this.conectado){
            System.out.println("Esta trabajando, porque esta conectado");
        }else{
            System.out.println("Acelerando el motor");
        }
    }

    public void detener(){
        if(!this.conectado){
            System.out.println("Debe desconectar primero la bateria/motor hibrido");
        }else{
            System.out.println("Deteniendo el motor");
        }
    }

    public void desconectar(){
        System.out.println("Desconectando el motor electrico y luego a gasolina");
        this.conectado = false;
    }
}
