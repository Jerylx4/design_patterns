package com.model;

import com.inter.Auto;

public class AutoGasolina implements Auto {

    public AutoGasolina(){
        System.out.println("Auto gasolina creado");
    }

    @Override
    public void encender() {
        System.out.println("Encendiendo auto a gasolina");
    }

    @Override
    public void acelerar() {
        System.out.println("Acelerando auto a gasolina");
    }

    @Override
    public void apagar() {
        System.out.println("Apagando auto a gasolina");
    }
}
