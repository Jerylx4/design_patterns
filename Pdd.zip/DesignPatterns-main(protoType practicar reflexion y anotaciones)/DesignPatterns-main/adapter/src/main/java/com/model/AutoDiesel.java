package com.model;

import com.inter.Auto;

public class AutoDiesel implements Auto {

    public AutoDiesel(){
        System.out.println("Auto diesel creado");
    }

    @Override
    public void encender() {
        System.out.println("Encendiendo auto a diesel");
    }

    @Override
    public void acelerar() {
        System.out.println("Acelerando auto a diesel");
    }

    @Override
    public void apagar() {
        System.out.println("Apagando auto a diesel");
    }
}
