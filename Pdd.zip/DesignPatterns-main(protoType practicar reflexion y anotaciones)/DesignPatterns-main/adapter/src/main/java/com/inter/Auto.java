package com.inter;

public interface Auto {
    void encender();
    void acelerar();
    void apagar();
}
