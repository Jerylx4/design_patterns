package com;

import com.impl.AutoHibridoAdapter;
import com.inter.Auto;
import com.model.AutoDiesel;
import com.model.AutoGasolina;
import com.model.AutoHibrido;

import java.util.Scanner;

public class App {
    static Auto auto;
    public static void main(String[] args) {


    }

    public static void usarAuto(){
        auto.encender();
        auto.acelerar();
        auto.apagar();
    }

    public static void menu(){
        int op;
        Scanner sc = new Scanner(System.in);
        switch(op=sc.nextInt()){
            case 1:
                auto = new AutoGasolina();
                break;
                case 2:
                    auto = new AutoDiesel();
                    break;
                    case 3:
                        auto = new AutoHibridoAdapter();
                        break;
                        default:

        }

    }

    public static int preguntarOpcion(){
        System.out.println("Menu:");
        System.out.println("1. Encender auto a gasolina");
        System.out.println("2. Encender auto a diesel");
        System.out.println("3. Encender auto hibrido");
        System.out.println("4. Desconectar");
        return
    }
}
