package com.main;

import com.dos.Libro;

public class App {
    public static void main(String[] args) {
//        Prue p = Prue.builder().name("ana").build();
//        System.out.println( p.toString());

        Libro lb = Libro.builder().idAutor("asdas").build();
        System.out.println(lb.toString());

    }
}
