package implementaciones;

import anotaciones.Productos;

@Productos(name = "prdCongeladoNitrogeno")
public class ProductoCongeladoNitrogeno extends ProductoCongelado {

    private String metodoCongelacion;
    private int tiempoExposicion;

    public ProductoCongeladoNitrogeno(){
        super();
    }

    public ProductoCongeladoNitrogeno(String fechaCaducidad, String numeroLote, String paisOrigen,
                                      String fechaEnvasado, double temperaturaMantenimiento,
                                      String metodo, int tiempoExposicion) {
        super(fechaCaducidad, numeroLote, paisOrigen, fechaEnvasado, temperaturaMantenimiento);
        this.metodoCongelacion = metodo;
        this.tiempoExposicion = tiempoExposicion;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Producto Congelado por Nitrógeno:");
        mostrarDatosBase();
        System.out.println("  Fecha envasado: " + fechaEnvasado);
        System.out.println("  Temp. mantenimiento: " + temperaturaMantenimiento + "°C");
        System.out.println("  Método: " + metodoCongelacion);
        System.out.println("  Tiempo exposición: " + tiempoExposicion + " s");
    }
}
