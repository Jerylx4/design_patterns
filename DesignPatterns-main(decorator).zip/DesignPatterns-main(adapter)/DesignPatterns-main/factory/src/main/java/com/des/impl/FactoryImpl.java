package com.des.impl;

import com.des.anotaciones.MiComponente;
import com.des.inter.IFactory;
import com.google.common.reflect.ClassPath;

import java.util.HashMap;
import java.util.Map;

//que es un java beens???????????idk

public class FactoryImpl implements IFactory {

    private Map<String, Class> comp = new HashMap<String, Class>();

    @Override
    public void init(String pkgName){
        System.out.println("inicializando buscando");
        try {
            ClassPath classPath = ClassPath.from(FactoryImpl.class.getClassLoader());
            var clases = classPath.getTopLevelClassesRecursive(pkgName);
            System.out.println("inicia " + clases.getClass().getName());
            for(var it : clases){
                var miComp = it.load().getAnnotation(MiComponente.class);
                if(miComp != null){
                    comp.put(miComp.name(),it.load());
                    System.out.println(miComp.name());
                }
            }

        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public <T> T createFactory(String name) {
        var value = comp.get(name);
        if(value == null){
            throw new RuntimeException("Componente : " + name + " no encontrado");
        }
        try{
            var cto = value.getConstructor();
            Object obj = cto.newInstance();
            return (T) obj;
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }
}
