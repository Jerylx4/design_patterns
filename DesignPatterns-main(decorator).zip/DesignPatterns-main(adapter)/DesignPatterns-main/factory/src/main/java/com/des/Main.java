package com.des;

import com.des.impl.FactoryImpl;
import com.des.inter.IFactory;
import com.des.modelos.Computadoras;

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<String,Class> compopnentes = new HashMap<String,Class>();
        IFactory fact = new FactoryImpl();
        fact.init("com.des.modelos");
        Computadoras pc = fact.createFactory("proxy");
    }

}
