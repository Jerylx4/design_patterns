package main;

import implementaciones.FactoryConcret;
import implementaciones.Producto;
import interfaces.IFactory;
import interfaces.IProducto;

public class Main {
    public static void main(String[] args) {

        IFactory fact = new FactoryConcret();
        fact.init("implementaciones");
        Producto test = fact.createFactory("prdFresco");
        test.mostrarDatosBase();





//        FactoryConcret factory = new FactoryConcret();
//
//        IProducto prb = factory.crearFactory(TipoProducto.FRESCO);
//        IProducto prb1= factory.crearFactory(TipoProducto.REFRIGERADO);
//        IProducto prb2 = factory.crearFactory(TipoProducto.CONGELADO_AIRE);
//
//
//        prb.mostrarInformacion();
//        System.out.println();
//        prb1.mostrarInformacion();
//        System.out.println();
//        prb2.mostrarInformacion();
    }
}

