package com.model;

import com.inter.Decorador;
import com.inter.Notificacion;
import org.gradle.internal.impldep.com.google.common.reflect.ClassPath;

import java.util.HashMap;
import java.util.Map;

public class DecoratorLoader {
    private Map<String, Class<?extends NotificacionDecorador>> decoradores = new HashMap<>();

    public void init(String pkgName){
        try{
            ClassPath classPath = ClassPath.from(getClass().getClassLoader());
            for (ClassPath.ClassInfo classInfo : classPath.getTopLevelClassesRecursive(pkgName)) {
                Class<?> clas = classInfo.load();
                if(Notificacion.class.isAssignableFrom(clas)){
                    Decorador annotacion = clas.getAnnotation(Decorador.class);
                    if(annotacion != null){
                        decoradores.put(annotacion.value(), (Class<? extends NotificacionDecorador>) clas);
                    }

                }
            }


        }catch(Exception e){
            throw new RuntimeException("Error al iniciar el decorador", e);
        }
    }

    public NotificacionDecorador createFactory(String decorador){
        Class<?extends NotificacionDecorador> decoradorClas = decoradores.get(decorador);
        if(decoradorClas == null){
            throw new RuntimeException("No se encontro el decorador " + decorador);
        } else {
            try{
                return decoradorClas.getDeclaredConstructor().newInstance();
            }catch(Exception e){
                throw new RuntimeException("Error al iniciar el decorador " + decorador, e);
            }
        }
    }
}
