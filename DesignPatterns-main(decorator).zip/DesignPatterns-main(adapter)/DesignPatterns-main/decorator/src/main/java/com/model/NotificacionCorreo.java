package com.model;

import com.inter.Decorador;
import com.inter.Notificacion;

@Decorador("correo")
public class NotificacionCorreo extends NotificacionDecorador {
    public NotificacionCorreo(Notificacion notificacion) {
        super(notificacion);
    }

    private void enviarCorreo(String msg) {
        System.out.println("Enviando mensaje a traves de Corrreo: "+ msg);
    }

    @Override
    public void enviar(String msg) {
        super.enviar(msg);
        this.enviarCorreo(msg);
    }
}
