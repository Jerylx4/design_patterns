package com.model;

import com.inter.Decorador;
import com.inter.Notificacion;

@Decorador("sms")
public class NotificacionSMS extends NotificacionDecorador {
    public NotificacionSMS(Notificacion notificacion) {
        super(notificacion);
    }

    private void enviarSMS(String msg) {
        System.out.println("Enviando mensaje a traves de SMS: "+ msg);
    }

    @Override
    public void enviar(String msg) {
        super.enviar(msg);
        this.enviarSMS(msg);
    }

}
