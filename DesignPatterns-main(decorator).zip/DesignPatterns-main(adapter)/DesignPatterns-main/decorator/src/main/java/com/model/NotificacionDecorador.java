package com.model;

import com.inter.Notificacion;

public abstract class NotificacionDecorador implements Notificacion {

    protected Notificacion notificacion;

    public NotificacionDecorador(Notificacion notificacion) {
        this.notificacion = notificacion;
    }

    @Override
    public void enviar(String msg) {
        notificacion.enviar(msg);
    }
}
