package com.model;

import com.inter.Decorador;
import com.inter.Notificacion;

@Decorador("push")
public class NotificacionPush extends NotificacionDecorador  {
    public NotificacionPush(Notificacion notificacion) {
        super(notificacion);
    }

    private void enviarPush(String msg) {
        System.out.println("Enviando mensaje a traves de Push: "+ msg);
    }

    @Override
    public void enviar(String msg) {
        super.enviar(msg);
        this.enviarPush(msg);
    }
}
