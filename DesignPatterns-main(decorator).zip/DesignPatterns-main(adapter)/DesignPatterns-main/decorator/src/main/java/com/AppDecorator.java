package com;

public class AppDecorator {
}
