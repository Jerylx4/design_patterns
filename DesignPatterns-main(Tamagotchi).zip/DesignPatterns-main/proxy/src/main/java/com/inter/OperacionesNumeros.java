package com.inter;

public interface OperacionesNumeros {
    int sumar(int x, int y);
    int restar(int x, int y);
}
