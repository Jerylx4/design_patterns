package com.main;

import lombok.*;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class Prue {
    private String name;
    private String tipo;
}
