package com.inter;

import java.util.Random;

public abstract class CarroBasico implements Cloneable {

    private String name;
    public int precio;
    private String marca = "Automovil";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrecio() {
        return precio;
    }

    public int setPrecio() {
        Random r = new Random();
        int price = 0;
        price = r.nextInt(10000);
        return price;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public CarroBasico clone() throws CloneNotSupportedException {
        return  (CarroBasico) super.clone();
    }

    @Override
    public String toString() {
        return name + " " + precio;
    }

}
