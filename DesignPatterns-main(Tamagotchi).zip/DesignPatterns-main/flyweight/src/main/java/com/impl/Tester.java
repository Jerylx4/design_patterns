package com.impl;

import com.inter.IEmpleado;

public class Tester implements IEmpleado {
    private String skill;
    private final String JOB;

    public Tester() {
        this.JOB = "Probar software desarrollado";
    }

    @Override
    public void assignSkill(String skill) {
        this.skill = skill;
    }

    @Override
    public void task() {
        System.out.println("Tester con habilidad de : " + skill +" cuyo trabajo es: "+JOB);
    }
}
