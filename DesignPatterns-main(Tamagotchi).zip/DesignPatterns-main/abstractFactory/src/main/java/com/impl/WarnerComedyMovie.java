package com.impl;

import com.inter.IWarnerMovie;

public class WarnerComedyMovie implements IWarnerMovie {
    @Override
    public String movieName() {
        return "Space Jam";
    }
}
