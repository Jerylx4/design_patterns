package com.model;

import com.observer.IObserver;
import com.state.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Tamagotchi {
    private IState estado;
    private int hunger = 50;
    private List<IObserver> observers = new ArrayList<>();
    private Map<String, IState> state = new HashMap<>();

    public Tamagotchi(){
        //Damos un estado inicial
    }

    private void loadState(){
        List<Class<?>> clases = List.of(
                HungryState.class,
                HappyState.class,
                SleepingState.class
        );

        for(Class<?> clas : clases){
            if(clas.isAnnotationPresent(TamagotchiState.class)){

            }
        }
    }

}
