package com.observer;

public class ConsolaObserver implements IObserver{

    @Override
    public void update(String state) {
        System.out.println("El estado ha cambiado a: " + state);
    }
}
