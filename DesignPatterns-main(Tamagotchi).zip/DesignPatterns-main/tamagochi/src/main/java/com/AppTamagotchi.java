package com;

public class AppTamagotchi {
}
