package com.state;

import com.model.Tamagotchi;

@TamagotchiState("HAPPY")
public class HappyState implements IState{

    @Override
    public void act(Tamagotchi tamagotchi) {
        System.out.println("El tamagotchi esta feliz");
    }
}
