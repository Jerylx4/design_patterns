package com.state;

import com.model.Tamagotchi;

@TamagotchiState("HUNGRY")
public class HungryState implements IState {

    @Override
    public void act(Tamagotchi tamagotchi) {
        System.out.println("El tamagotchi tiene mucha hambre");
    }
}
