package com.state;

import com.model.Tamagotchi;

public interface IState {
    void act(Tamagotchi tamagotchi);
}
