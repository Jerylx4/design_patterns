package com.factory;

import com.build.Libro;

public class LibroFactory implements IFactoryLibro {
    @Override
    public Libro crearLibro(Integer id, String titulo, String isbn, String idAutor) {

        return Libro.builder()
                .id(id)
                .titulo(titulo)
                .isbn(isbn)
                .idAutor(idAutor)
                .build();
    }
}
