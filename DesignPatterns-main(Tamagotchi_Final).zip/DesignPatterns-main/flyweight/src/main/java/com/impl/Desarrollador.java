package com.impl;

import com.inter.IEmpleado;

public class Desarrollador implements IEmpleado{
    private String skill;
    private final String JOB;

    public Desarrollador() {
        this.JOB = "desarrollador de software";
    }

    @Override
    public void assignSkill(String skill) {
        this.skill = skill;
    }

    @Override
    public void task() {
        System.out.println("Desarrollador con habilidad de : " + skill +" cuyo trabajo es: "+JOB);
    }
}
