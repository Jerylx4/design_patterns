package main;

public enum TipoProducto {
    FRESCO,
    REFRIGERADO,
    CONGELADO_AIRE,
    CONGELADO_AGUA,
    CONGELADO_NITROGENO
}
