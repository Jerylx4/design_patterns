package com.state;

import com.model.Tamagotchi;
import com.strategy.IComidaStrategy;

public interface IState {
    void onActividad(Tamagotchi t);
    void onComer(Tamagotchi t, IComidaStrategy s);
    void onDormir(Tamagotchi t);
    void onDescanso(Tamagotchi t);
}
