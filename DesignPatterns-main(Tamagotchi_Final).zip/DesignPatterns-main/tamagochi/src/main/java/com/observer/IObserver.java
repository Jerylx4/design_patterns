package com.observer;

public interface IObserver {
    void update(String state);
}
