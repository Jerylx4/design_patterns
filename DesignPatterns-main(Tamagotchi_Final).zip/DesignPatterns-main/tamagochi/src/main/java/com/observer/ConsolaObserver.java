package com.observer;

public class ConsolaObserver implements IObserver{

    @Override
    public void update(String state) {
        System.out.println("\nEl estado ha cambiado a: " + state);
    }
}
