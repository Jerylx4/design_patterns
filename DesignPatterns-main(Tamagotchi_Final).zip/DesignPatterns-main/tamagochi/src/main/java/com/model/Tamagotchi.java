package com.model;

import com.google.common.reflect.ClassPath;
import com.observer.IObserver;
import com.state.*;
import com.strategy.IComidaStrategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Tamagotchi {
    private IState estado;
    private int hunger = 50;
    private List<IObserver> observers = new ArrayList<>();
    private Map<String, IState> state = new HashMap<>();

    public Tamagotchi(){
        loadState("com.state");
        setState("HAPPY");
    }

    private void loadState(String pkgName){
        try{
            ClassPath classPath = ClassPath.from(Tamagotchi.class.getClassLoader());
            var classes = classPath.getTopLevelClassesRecursive(pkgName);
            for(var classInfo : classes){
                Class<?> clazz = classInfo.load();
                if(!IState.class.isAssignableFrom(clazz)){
                    continue;
                }
                TamagotchiState annotation = clazz.getAnnotation(TamagotchiState.class);
                if(annotation != null){
                    IState instance = (IState)clazz.getDeclaredConstructor().newInstance();
                    state.put(annotation.value(), instance);
                    System.out.println("Estado cargado: " + annotation + "-> " + clazz.getSimpleName());
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void setState(String name){
        estado = state.get(name);
        notifyObserver(name);
    }

    public void addObserver(IObserver o){
        observers.add(o);
    }

    public void notifyObserver(String state){
        observers.forEach(x -> x.update(state));
    }

    public void feed(IComidaStrategy strategy){
        estado.onComer(this, strategy);

    }

    public void act(){
        estado.onActividad(this);
    }

    public void sleep(){
        estado.onDormir(this);
    }

    public void passTime(){
        estado.onDescanso(this);
    }

    public void incHunger(int value){
        hunger += value;
    }

}
