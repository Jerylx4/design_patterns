package com;

public class AppFacade {
    public static void main(String[] args) {
        ComputadoraFacade com = new  ComputadoraFacade("16 Gb","1 Tb", "i7");

    }
}
