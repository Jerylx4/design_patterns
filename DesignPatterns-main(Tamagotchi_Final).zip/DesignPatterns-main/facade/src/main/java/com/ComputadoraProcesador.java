package com;

public class ComputadoraProcesador {
    private String procesador;

    public void crearProcesador(String procesador){
        this.procesador = procesador;
        System.out.println("Se ha agregado el procesador: "+procesador);
    }
}
