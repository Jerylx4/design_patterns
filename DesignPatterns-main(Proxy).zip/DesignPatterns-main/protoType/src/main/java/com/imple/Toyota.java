package com.imple;

import com.inter.CarroBasico;

public class Toyota extends CarroBasico {
    public Toyota(String name){
        setName(name);
    }

    @Override
    public CarroBasico clone() throws CloneNotSupportedException{
        return (Toyota)super.clone();
    }
}
