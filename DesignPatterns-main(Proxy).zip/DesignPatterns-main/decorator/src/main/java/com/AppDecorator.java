package com;

import com.inter.INotificacion;


public class AppDecorator {



}
