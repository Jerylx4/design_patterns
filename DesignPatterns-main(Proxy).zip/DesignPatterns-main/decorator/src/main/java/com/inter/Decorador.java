package com.inter;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
//añadir metadata en tiempo de ejcucion
@Retention(RetentionPolicy.RUNTIME)
public @interface Decorador {
    String value();


}
