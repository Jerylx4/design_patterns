package com.base;

import com.inter.INotificacion;

public class NotificacionBase implements INotificacion { //objeto original
    @Override
    public void enviar(String msg) {
        System.out.printf("Enviando mensaje con el objeto original: " + msg);
    }
}
