package com.modelo;

import com.inter.Auto;

public class AutoDiesel implements Auto {

    public AutoDiesel(){}

    @Override
    public void enceder() {
        System.out.println("Auto Diesel encendido");
    }

    @Override
    public void acelerar() {
        System.out.println("Auto Diesel acelerado");
    }

    @Override
    public void apagar() {
        System.out.println("Auto Diesel apagado");
    }
}
