package com.modelo;

import com.inter.Auto;

public class AutoGasolina implements Auto {

    public AutoGasolina(){}

    @Override
    public void enceder() {
        System.out.println("Auto Gasolina Encendido");
    }

    @Override
    public void acelerar() {
        System.out.println("Auto Gasolina Acelerado");
    }

    @Override
    public void apagar() {
        System.out.println("Auto Gasolina Apagado");
    }
}
