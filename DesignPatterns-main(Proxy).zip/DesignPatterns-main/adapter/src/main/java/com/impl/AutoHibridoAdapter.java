package com.impl;

import com.inter.Auto;
import com.modelo.AutoGasolina;
import com.modelo.AutoHibrido;

public class AutoHibridoAdapter implements Auto {

    private AutoHibrido autoHibrido;

    public AutoHibridoAdapter(){
        System.out.println("Creando AutoHibrido a traves del adapter");
        this.autoHibrido = new AutoHibrido();

    }

    @Override
    public void enceder() {
        System.out.println("Encendiendo auto hibrido a traves del adapter");
        this.autoHibrido.conectar();
        this.autoHibrido.activar();
    }

    @Override
    public void acelerar() {
        System.out.println("Acelerando auto hibrido a traves del adapter");
        this.autoHibrido.moverRapido();
    }

    @Override
    public void apagar() {
        System.out.println("Apagando auto hibrido a traves del adapter");
        this.autoHibrido.detener();
        this.autoHibrido.desconectar();
    }
}
