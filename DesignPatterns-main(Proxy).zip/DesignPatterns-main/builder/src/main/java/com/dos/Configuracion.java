package com.dos;

public class Configuracion {
}
