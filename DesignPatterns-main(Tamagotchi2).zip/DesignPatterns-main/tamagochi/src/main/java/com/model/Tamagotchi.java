package com.model;

import com.observer.IObserver;
import com.state.*;
import com.strategy.IComidaStrategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Tamagotchi {
    private IState estado;
    private int hunger = 50;
    private List<IObserver> observers = new ArrayList<>();
    private Map<String, IState> state = new HashMap<>();

    public Tamagotchi(){
        loadState();
        setState("HAPPY");

    }

    private void loadState(){
        List<Class<?>> clases = List.of(
                HungryState.class,
                HappyState.class,
                SleepingState.class
        );

        for(Class<?> clas : clases){
            if(clas.isAnnotationPresent(TamagotchiState.class)){
                try{
                    TamagotchiState a= clas.getAnnotation(TamagotchiState.class);
                    state.put(a.value(),(IState) clas.getDeclaredConstructor().newInstance());
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
    public void setState(String name){
        estado = state.get(name);
        notifyObserver(name);
    }

    public void addObserver(IObserver o){
        observers.add(o);
    }

    public void notifyObserver(String state){
        observers.forEach(x -> x.update(state));
    }

    public void feed(IComidaStrategy strategy){
        hunger += strategy.feed();
        if(hunger > 60){
            setState("HAPPY");
        }
    }

    public void act(){
        estado.act(this);
    }


}
