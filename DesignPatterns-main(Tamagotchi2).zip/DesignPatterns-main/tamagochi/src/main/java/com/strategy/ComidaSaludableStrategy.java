package com.strategy;

public class ComidaSaludableStrategy implements IComidaStrategy {

    @Override
    public int feed() {
        return 10;
    }
}
