package com.strategy;

public class ComidaRapidaStrategy implements IComidaStrategy {

    @Override
    public int feed() {

        return 5;
    }
}
