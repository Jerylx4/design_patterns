package com.state;

import com.model.Tamagotchi;

@TamagotchiState("SLEEPING")
public class SleepingState implements IState{

    @Override
    public void act(Tamagotchi tamagotchi) {
        System.out.println("El tamagotchi esta durmiendo");
    }
}
