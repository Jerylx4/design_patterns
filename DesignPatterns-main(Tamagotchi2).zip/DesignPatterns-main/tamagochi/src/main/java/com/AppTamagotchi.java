package com;

import com.model.Tamagotchi;
import com.observer.ConsolaObserver;
import com.strategy.ComidaRapidaStrategy;

public class AppTamagotchi {
    public static void main(String[] args) {
        Tamagotchi t = new Tamagotchi();
        t.addObserver(new ConsolaObserver());
        t.act();
        t.setState("HUNGRY");
        t.act();
        t.feed(new ComidaRapidaStrategy());
        t.act();
        t.setState("SLEEPING");
        t.act();
    }
}
