package com.impl;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;

public final class OperacionesFactory {

    public static Object crearProxy(Object target){
        Object proxy= Proxy.
                newProxyInstance(
                        OperacionesFactory.class.getClassLoader(),
                        target.getClass().getInterfaces(),
                        new ImpresionInvocationHandler(target));

        return proxy;
    }

    static class ImpresionInvocationHandler implements InvocationHandler {
        private Object target;

        public ImpresionInvocationHandler(Object target){
            this.target=target;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            System.out.printf("----------- Invocando a %s(%s): ", method.getName(), Arrays.toString(args));
            long inicio=System.nanoTime();
            Object res= method.invoke(target,args);
            long t=System.nanoTime()-inicio;
            System.out.printf("Tiempo %.3 ms/n", t/1000.0f);
            return res;
        }
    }
}
