package com.impl;

import com.inter.OperacionesNumeros;

public class OperacionesNumerosProxy implements OperacionesNumeros {
    private OperacionesNumerosImpl target = new OperacionesNumerosImpl();

    @Override
    public int sumar(int x, int y) {
        System.out.println("Antes");
        int res = target.sumar(x, y);
        System.out.println("Despues");
        return res;
    }
    @Override
    public int restar(int x, int y) {
        System.out.println("Antes");
        int res = target.restar(x, y);
        System.out.println("Despues");
        return res;
    }
}
