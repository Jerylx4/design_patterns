package com.impl;

import com.inter.IWarnerMovie;

public class WarnerActionMovie implements IWarnerMovie {
    @Override
    public String movieName() {
        return "Batman";
    }
}
