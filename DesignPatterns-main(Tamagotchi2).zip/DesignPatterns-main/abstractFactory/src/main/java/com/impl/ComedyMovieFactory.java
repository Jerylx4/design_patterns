package com.impl;

import com.inter.IDisneyMovie;
import com.inter.IMovieFactory;
import com.inter.IWarnerMovie;

public class ComedyMovieFactory implements IMovieFactory {
    @Override
    public IWarnerMovie getWarnerMovie() {
        return new WarnerComedyMovie();
    }

    @Override
    public IDisneyMovie getDisneyMovie() {
        return new DisneyComedyMovie();
    }
}
