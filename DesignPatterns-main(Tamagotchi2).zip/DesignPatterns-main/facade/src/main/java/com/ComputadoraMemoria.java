package com;

public class ComputadoraMemoria {
    private String disco;
    private String ram;

    public void crearMemoria(String disco, String ram) {
        this.disco = disco;
        this.ram = ram;
        System.out.println("Se ha agregado memoria al computador:  "+ disco +" de disco, "+ ram+ "de ram");
    }

}
