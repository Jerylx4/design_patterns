package com;

public class ComputadoraFacade {
    private ComputadoraMainboard mainboard;
    private ComputadoraMemoria memoria;
    private ComputadoraProcesador procesador;

    public ComputadoraFacade (){
        this.memoria = new ComputadoraMemoria();
        this.mainboard = new ComputadoraMainboard();
        this.procesador = new ComputadoraProcesador();
    }

    public ComputadoraFacade (String ram, String disco, String procesador){
        this();
        memoria.crearMemoria(disco, ram);
        this.procesador.crearProcesador(procesador);
    }


}
