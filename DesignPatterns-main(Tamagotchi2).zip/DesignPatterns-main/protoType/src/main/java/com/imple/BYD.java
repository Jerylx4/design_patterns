package com.imple;

import com.inter.CarroBasico;

public class BYD extends CarroBasico {
    public  BYD(String name){
        setName(name);
    }

    @Override
    public CarroBasico clone() throws CloneNotSupportedException{
        return (BYD)super.clone();
    }
}
