package com.imple;

import com.inter.CarroBasico;

public class Ford extends CarroBasico {
    public Ford(String name){
        setName(name);
    }

    @Override
    public CarroBasico clone() throws CloneNotSupportedException{
        return (Ford)super.clone();
    }
}
