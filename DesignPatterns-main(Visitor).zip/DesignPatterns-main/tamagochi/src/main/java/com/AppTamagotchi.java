package com;

import com.model.Tamagotchi;
import com.observer.ConsolaObserver;
import com.strategy.ComidaRapidaStrategy;
import com.strategy.ComidaSaludableStrategy;

import java.util.Scanner;

public class AppTamagotchi {
    public static void main(String[] args) {
        Tamagotchi t= new Tamagotchi();
        t.addObserver(new ConsolaObserver());
        System.out.println("Bienvenido al juego del Tamagotchi");
        menu(t);
    }

    public static void menu(Tamagotchi t){
        Scanner sc= new Scanner(System.in);
        boolean ejecutar = true;

        System.out.println("1. Jugar\n2. Alimentar CR\n3. Alimentar CS   \n4. Dormir\n5. Descansar\n6. Salir");
        while(ejecutar= true){
            System.out.println("Escoja una opcion: ");
            int op= sc.nextInt();
            switch (op){
                case 1 -> t.act();
                case 2 -> t.feed(new ComidaRapidaStrategy());
                case 3 -> t.feed(new ComidaSaludableStrategy());
                case 4 -> t.sleep();
                case 5 -> t.passTime();
                case 6 -> {
                    ejecutar = false;
                    System.out.println("Hasta pronto");
                }
                default -> System.out.println("Opcion invalida");
            }

        }
    }
}
