package com.state;

import com.model.Tamagotchi;
import com.strategy.IComidaStrategy;


@TamagotchiState("HUNGRY")
public class HungryState implements IState {

    @Override
    public void onActividad(Tamagotchi t) {
        System.out.println("Estoy hambriento, no quiero jugar");
    }

    @Override
    public void onComer(Tamagotchi t, IComidaStrategy s) {
        int value = s.feed();
        t.incHunger(value);
        System.out.println("Comer, yupiii, ahora me siento mejor");
        t.setState("HAPPY");
    }

    @Override
    public void onDormir(Tamagotchi t) {
        System.out.println("No puedo dormir con hambre");

    }

    @Override
    public void onDescanso(Tamagotchi t) {
        System.out.println("No puedo descansar con hambre");
    }
}
