package com.state;

import com.model.Tamagotchi;
import com.strategy.IComidaStrategy;

@TamagotchiState("SLEEPING")
public class SleepingState implements IState{


    @Override
    public void onActividad(Tamagotchi t) {
        System.out.println("Zzz...");
    }

    @Override
    public void onComer(Tamagotchi t, IComidaStrategy s) {
        System.out.println("Zzz...");
    }

    @Override
    public void onDormir(Tamagotchi t) {
        System.out.println("Zzz...");
    }

    @Override
    public void onDescanso(Tamagotchi t) {
        System.out.println("Ya se esta despertando");
        t.setState("HUNGRY");
    }
}
