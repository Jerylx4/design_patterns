package com.impl;

import com.interfaz.Mediator;

public abstract class Usuarios {
    protected Mediator mediador;
    protected String name;

    public abstract void send(String mns);
    public abstract void receive(String mns);

    public Usuarios(Mediator mediador, String name){
        this.mediador = mediador;
        this.name = name;
    }

}
