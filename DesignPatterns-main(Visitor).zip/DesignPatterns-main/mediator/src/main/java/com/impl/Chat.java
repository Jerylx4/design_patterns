package com.impl;

import com.interfaz.Mediator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Chat implements Mediator {
    private List<Usuarios> users = new ArrayList<>();
    private Lock lock = new ReentrantLock();

    @Override
    public void sendMessage(String mns, Usuarios user) {
        lock.lock();
        try {
            for (var u: users){
                if(u != user){
                    u.receive(mns);

                }
            }
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void addUser(Usuarios user) {
        users.add(user);
    }
}
