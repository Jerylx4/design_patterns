package com.impl;

import com.interfaz.Mediator;

public class ConcretUsuario extends Usuarios{
    public ConcretUsuario(Mediator mediador, String name) {
        super(mediador, name);
    }

    @Override
    public void send(String mns) {
        System.out.println(name +" esta enviando un mensaje: "+ mns);
        mediador.sendMessage(mns, this);
    }

    @Override
    public void receive(String mns) {
        System.out.println(name +" esta rescibiendo mensaje: "+ mns);
    }
}
