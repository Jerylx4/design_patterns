package com.interfaz;

import com.impl.Usuarios;

public interface Mediator {
    void sendMessage(String mns, Usuarios user);
    void addUser(Usuarios user);
}
