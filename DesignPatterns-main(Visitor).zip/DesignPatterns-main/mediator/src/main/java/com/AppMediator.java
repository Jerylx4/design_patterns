package com;

import com.impl.Chat;
import com.impl.ConcretUsuario;
import com.impl.Usuarios;
import com.interfaz.Mediator;

public class AppMediator {
    public static void main(String[] args) {
        Mediator salaChat = new Chat();
        Usuarios user1 = new ConcretUsuario(salaChat, "Ana");
        Usuarios user2 = new ConcretUsuario(salaChat, "Erick");
        Usuarios user3 = new ConcretUsuario(salaChat, "Juan");
        Usuarios user4 = new ConcretUsuario(salaChat, "Alex");

        salaChat.addUser(user1);
        salaChat.addUser(user2);
        salaChat.addUser(user3);
        salaChat.addUser(user4);

        user1.send("Hola chicos");
        user2.send("Que mas");
        user3.send("Confirma");
        user4.send("Al quitus no");
    }

}
