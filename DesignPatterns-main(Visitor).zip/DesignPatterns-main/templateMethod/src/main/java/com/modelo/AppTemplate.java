package com.modelo;

import java.util.Scanner;

public class AppTemplate {

    public static void main(String[] args) {
        Cajero cajero = new Cajero("123456CA", 789);
        CajeroAutomatico ca= new CajeroAutomatico("56789CC", 2540);
        cajero.procesar(cajero.getCuenta(), 250, menu());
        ca.procesar(ca.getCuenta(), 780, menu());
    }

    public static int menu(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Escoja una opcion \n1. Depositar\n2. Retirar\n3. Consultar saldo");
        return sc.nextInt();
    }

}
