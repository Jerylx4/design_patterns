package com.modelo;

public class CajeroAutomatico extends CuentaBancaria{

    public CajeroAutomatico(String cuenta, int saldo) {
        super(cuenta, saldo);
    }

    @Override
    public void confirmar() {
        System.out.println("Que tipo de transaccion va a realizar");
    }

    @Override
    public void auditoria(){
        super.auditoria();
        System.out.println("Transaccion realizada con exito");
    }
}
