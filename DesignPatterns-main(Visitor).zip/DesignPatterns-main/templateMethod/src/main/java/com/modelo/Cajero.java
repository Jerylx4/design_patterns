package com.modelo;

public class Cajero extends CuentaBancaria{
    private String name = "ANA";

    public Cajero(String cuenta, int saldo) {
        super(cuenta, saldo);
    }

    @Override
    public void confirmar() {
        System.out.println("Bienvenido al banco, que transaccion va a realizar, mi nombre es: "+ this.name);

    }

    @Override
    public void auditoria(){
        super.auditoria();
        System.out.println("Fue un placer atenderle");
    }
}
