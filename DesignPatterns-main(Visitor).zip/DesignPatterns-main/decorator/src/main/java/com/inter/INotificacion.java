package com.inter;

public interface INotificacion {
    void enviar(String msg);
}
