package com.dos;

import lombok.Builder;

public record Libro(Integer id, String titulo, String isbn, String idAutor) {
    public static Builder builder(){
        return new Builder();
    }
    public static class Builder{
        private Integer id;
        private String titulo;
        private String isbn;
        private String idAutor;

        public Builder(){

        }

        public Builder id(Integer id){
            this.id = id;
            return this;
        }
        public Builder titulo(String titulo){
            this.titulo = titulo;
            return this;
        }
        public Builder isbn(String isbn){
            this.isbn = isbn;
            return this;
        }
        public Builder idAutor(String idAutor){
            this.idAutor = idAutor;
            return this;
        }

        public Libro build(){
            return new Libro(id,titulo,isbn,idAutor);
        }
    }
}
