package com;


import org.lwjgl.Version;

import org.lwjgl.glfw.GLFWErrorCallback;
import java.nio.IntBuffer;
import com.figuras.Color;
import com.figuras.Graficos;
import com.impl.Triangulo;
import com.inter.FiguraGeometrica;
import org.lwjgl.glfw.GLFWErrorCallback;
//import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;
import org.lwjgl.system.MemoryStack;
import static org.lwjgl.glfw.Callbacks.glfwFreeCallbacks;
import static org.lwjgl.glfw.GLFW.GLFW_FALSE;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_F1;
import static org.lwjgl.glfw.GLFW.GLFW_KEY_F2;
import static org.lwjgl.glfw.GLFW.GLFW_RELEASE;
import static org.lwjgl.glfw.GLFW.GLFW_TRUE;
import static org.lwjgl.glfw.GLFW.GLFW_VISIBLE;
import static org.lwjgl.glfw.GLFW.glfwCreateWindow;
import static org.lwjgl.glfw.GLFW.glfwDefaultWindowHints;
import static org.lwjgl.glfw.GLFW.glfwDestroyWindow;
import static org.lwjgl.glfw.GLFW.glfwGetPrimaryMonitor;
import static org.lwjgl.glfw.GLFW.glfwGetVideoMode;
import static org.lwjgl.glfw.GLFW.glfwGetWindowSize;
import static org.lwjgl.glfw.GLFW.glfwInit;
import static org.lwjgl.glfw.GLFW.glfwMakeContextCurrent;
import static org.lwjgl.glfw.GLFW.glfwPollEvents;
import static org.lwjgl.glfw.GLFW.glfwSetErrorCallback;
import static org.lwjgl.glfw.GLFW.glfwSetKeyCallback;
import static org.lwjgl.glfw.GLFW.glfwSetWindowPos;
import static org.lwjgl.glfw.GLFW.glfwSetWindowShouldClose;
import static org.lwjgl.glfw.GLFW.glfwShowWindow;
import static org.lwjgl.glfw.GLFW.glfwSwapBuffers;
import static org.lwjgl.glfw.GLFW.glfwSwapInterval;
import static org.lwjgl.glfw.GLFW.glfwTerminate;
import static org.lwjgl.glfw.GLFW.glfwWindowHint;
import static org.lwjgl.glfw.GLFW.glfwWindowShouldClose;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_FILL;
import static org.lwjgl.opengl.GL11.GL_FRONT_AND_BACK;
import static org.lwjgl.opengl.GL11.GL_LINE;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glPolygonMode;
import static org.lwjgl.system.MemoryStack.stackPush;
import static org.lwjgl.system.MemoryUtil.NULL;

public class AppFiguras {
	public static long window;
	public static Graficos graficos = new Graficos();
	
	
	public static void init() {
		//CONFIGURAR UN CALLBACK, INICIALIZAR GLFW, CONFIGURAR PROPIEDADES DE LA VENTANA, CREAR LA VENTANA
		GLFWErrorCallback.createPrint(System.err).set();
		//Este bloque de código inicializa GLFW, crea una ventana OpenGL y define un callback de teclado para gestionar eventos clave.
		if(!glfwInit())
			throw new IllegalStateException("Falla en la inicialización de GLFW window");
		glfwDefaultWindowHints(); // restablece todas las pistas de ventana (window hints) a sus valores predeterminados antes de crear una nueva ventana.
		glfwWindowHint(GLFW_VISIBLE, GLFW_TRUE); //configurar la visibilidad de la ventana antes de crearla. A,B, a deine que deberá ser visible al crearse, b es visible inmediatamente despues de crearse
		window = glfwCreateWindow(800, 600, "Composite", NULL, NULL);
		if(window == NULL)
			throw new RuntimeException(" Falla en la creacion de la ventana");
		glfwSetKeyCallback(window,(window, key,scancode, action, mods) -> {
			if(key == GLFW_KEY_ESCAPE && action == GLFW_RELEASE)
				glfwSetWindowShouldClose(window, true);
			else if(key == GLFW_KEY_F1) {
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);//CREA POLIGONO SOLO CON LINEA
			}else if(key == GLFW_KEY_F2) {
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);//CREA POLIGONO SOLIDO CON RELLENO
			}
		});
		
		try(MemoryStack stack = stackPush()) {
			IntBuffer pWindth = stack.mallocInt(1);
			IntBuffer pHeight = stack.mallocInt(1);
			glfwGetWindowSize(window, pWindth, pHeight);
			GLFWVidMode vidmode = glfwGetVideoMode(glfwGetPrimaryMonitor());
			glfwSetWindowPos(window, (vidmode.width() - pWindth.get(0))/2, 
					(vidmode.height() - pHeight.get(0))/2);
		}
		
		glfwMakeContextCurrent(window); //Establece el contexto OpenGL actual para la ventana especificada
		glfwSwapInterval(1); //Establece el intervalo de sincronización vertical (V-Sync) para la ventana
		glfwShowWindow(window);//Muestra la ventana que fue creada previamente .
	}
	public static void loop() {
		GL.createCapabilities(); // inicializa las capacidades de OpenGL. asegura que OpenGL está correctamente configurado y se puede empezar a usar para el renderizado.
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f); //Establece el color de fondo de la ventana.RGB y transparencia

		while(!glfwWindowShouldClose(window)) { //Inicia un bucle de renderizado que se ejecuta mientras la ventana no esté cerrada.
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT); //Limpia los buffers de color y de profundidad antes de renderizar cada cuadro.
			graficos.draw();
			glfwSwapBuffers(window); // Intercambia los buffers de la ventana, mostrando el contenido recién renderizado.
			glfwPollEvents(); //Gestiona los eventos de la ventana.
		}
	}
	public static void run() {
		System.out.println("Gráficos" + Version.getVersion());
		init();
		loop();
		glfwFreeCallbacks(window);
		glfwDestroyWindow(window);;
		glfwTerminate();
		glfwSetErrorCallback(null).free();
	}
	public static void main(String[] args) {
		Triangulo f1 = new Triangulo(0, 0, 1, 1, 1, 0, Color.GREEN);
		Triangulo f2 = new Triangulo(-0.5f, -0.5f, -0.5f, 0, 0, 0, Color.BLUE);
		Triangulo f3 = new Triangulo(-0.5f, 0.5f, -0.5f, 0, 0, 0, Color.RED);

		f1.setRot(0, 1, 0);
		f2.setRot(0, 0, 1);
		f3.setRot(1, 0, 0);
		
	    graficos.add(f1);
	    graficos.add(f2);
	    graficos.add(f3);

		System.setProperty("org.lwjgl.librarypath", "c:/ogl");
	/*	init();
		loop();
		glfwFreeCallbacks(window);
		glfwDestroyWindow(window);
		glfwTerminate();
		glfwSetErrorCallback(null).free();*/
		//graficos.draw();
		AppFiguras.run();
		
		
	}

}
