package com.figuras;

import java.util.ArrayList;
import java.util.List;

import com.inter.FiguraGeometrica;

public class Graficos implements FiguraGeometrica{
	private List<FiguraGeometrica> figuras = new ArrayList<FiguraGeometrica>();
	
	public void add(FiguraGeometrica fig) {
		figuras.add(fig);
	}

	public void remove(FiguraGeometrica fig) {
		figuras.remove(fig);
	}
	public void clear() {
		figuras.clear();
	}
	@Override
	public void draw() {
		for(var obj: figuras) {
			obj.draw();
		}
		
	}

}
