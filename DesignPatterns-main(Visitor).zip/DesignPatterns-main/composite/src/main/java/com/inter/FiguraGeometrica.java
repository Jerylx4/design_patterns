package com.inter;

public interface FiguraGeometrica {
	void draw();
}
