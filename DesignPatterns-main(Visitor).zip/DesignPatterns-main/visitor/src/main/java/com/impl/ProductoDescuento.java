package com.impl;

import com.interfaz.Visitable;
import com.interfaz.Visitor;

public class ProductoDescuento implements Visitable {
    private double precio;

    public ProductoDescuento(double precio) {
        this.precio = precio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }


    @Override
    public double accept(Visitor v) {
        return v.visit(this);
    }
}
