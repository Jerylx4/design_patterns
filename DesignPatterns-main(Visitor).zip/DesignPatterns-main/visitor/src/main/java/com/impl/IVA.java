package com.impl;

import com.interfaz.Visitor;

public class IVA implements Visitor {
    private final double impNormal = 1.12;
    private final double impDesc = 1.02;

    @Override
    public double visit(ProductoNormal p) {
        return p.getPrecio() * impNormal;
    }

    @Override
    public double visit(ProductoDescuento p) {
        return p.getPrecio() * impDesc;
    }
}
