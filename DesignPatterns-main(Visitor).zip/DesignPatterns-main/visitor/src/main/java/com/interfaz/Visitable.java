package com.interfaz;

public interface Visitable {
    double accept(Visitor v);
}
