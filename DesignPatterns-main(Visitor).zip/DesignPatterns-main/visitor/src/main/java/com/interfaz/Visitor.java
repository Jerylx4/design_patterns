package com.interfaz;

import com.impl.ProductoDescuento;
import com.impl.ProductoNormal;

public interface Visitor {
    double visit(ProductoNormal p);
    double visit(ProductoDescuento p);


}
