package com;

import com.impl.IVA;
import com.impl.ProductoDescuento;
import com.impl.ProductoNormal;

public class AppVisitor {
    public static void main(String[] args) {
        ProductoNormal pn = new ProductoNormal(0);
        pn.setPrecio(120);
        ProductoDescuento pd = new ProductoDescuento(0);
        pd.setPrecio(120);

        IVA i = new IVA();
        double res1 = pd.accept(i);
        double res2 = pn.accept(i);

        System.out.println(res1);
        System.out.println(res2);


    }
}
