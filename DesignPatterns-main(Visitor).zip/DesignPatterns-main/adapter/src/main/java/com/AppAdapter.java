package com;

import com.impl.AutoHibridoAdapter;
import com.inter.Auto;
import com.modelo.AutoDiesel;
import com.modelo.AutoGasolina;
import com.modelo.AutoHibrido;

import java.util.Scanner;

public class AppAdapter { //patron estructural

    static Auto auto;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
            menu();

    }

    public static void usarAuto() {
        auto.enceder();
        auto.acelerar();
        auto.apagar();
    }

    public static void menu() {
        int op;
        op = preguntarOpcion();
        switch (op) {
            case 1:
                auto = new AutoGasolina();
                usarAuto();
                break;
            case 2:
                auto = new AutoDiesel();
                usarAuto();
                break;
            case 3:
                auto = new AutoHibridoAdapter();
                usarAuto();
                break;
                default:
        }
    }

    public static int preguntarOpcion() {
        System.out.println("Menu: ");
        System.out.println("1. Encender auto a gasolina");
        System.out.println("2. Encender auto a diesel");
        System.out.println("3. Encender auto hibrido");
        System.out.println("Seleccione la opcion: ");

        return Integer.parseInt(sc.nextLine());
    }
}
