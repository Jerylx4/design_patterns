package com.inter;

public interface IDisneyMovie {
    String movieName();
}
