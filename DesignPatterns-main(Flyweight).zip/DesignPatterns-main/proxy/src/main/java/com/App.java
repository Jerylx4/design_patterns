package com;

import com.impl.OperacionesNumerosProxy;

public class App {
    public static void main(String[] args) {
        OperacionesNumerosProxy proxy = new OperacionesNumerosProxy();
        System.out.println(proxy.sumar(2,4));
        System.out.println(proxy.restar(9,4));
    }
}
