package com;

public class ComputadoraMainboard {
    private String mainboard;

    public void crearMainboard(String mainboard){
        this.mainboard = "Mainboard compatible";
        System.out.println("Se ha agregado el mainboard compatible : "+mainboard);
    }
}
