package implementaciones;

import anotaciones.Productos;
import interfaces.IProducto;


public abstract class Producto implements IProducto {

    protected String fechaCaducidad;
    protected String numeroLote;
    protected String paisOrigen;

    public Producto(String fechaCaducidad, String numeroLote, String paisOrigen) {
        this.fechaCaducidad = fechaCaducidad;
        this.numeroLote = numeroLote;
        this.paisOrigen = paisOrigen;
    }

    public Producto() {

    }


    public void mostrarDatosBase() {
        System.out.println("  Fecha caducidad: " + fechaCaducidad);
        System.out.println("  N° lote: " + numeroLote);
        System.out.println("  País origen: " + paisOrigen);
    }
}

