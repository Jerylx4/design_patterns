package com;

import com.impl.EmpleadoFabrica;
import com.inter.IEmpleado;

import java.util.Random;

public class App {
    private static String[] empleadoTipo = {"Desarrollador", "Tester"};
    private static String[] habilidades = {"Java", "Python", "C++", "C#"};

    public static void main(String[] args) {
        for(int i=0 ; i<15 ; i++){
            IEmpleado e = EmpleadoFabrica.getEmpleado(getRandEmpleado());
            e.assignSkill(getRandHabilidades());
            e.task();
        }
    }

    public static String getRandEmpleado() {
       Random r = new Random();
       int rand = r.nextInt(empleadoTipo.length);
       return empleadoTipo[rand];
    }

    public static String getRandHabilidades() {
        Random r = new Random();
        int rand = r.nextInt(habilidades.length);
        return habilidades[rand];
    }
}
