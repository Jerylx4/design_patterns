package com.inter;

public interface Auto {

    public void enceder();
    public void acelerar();
    public void apagar();
}
