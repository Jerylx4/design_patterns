package com.model;

import com.inter.Decorador;
import com.inter.INotificacion;
@Decorador("sms")

public class NotificacionSMS extends NotificacionDecorador{
    public NotificacionSMS(INotificacion notificacion) {
        super(notificacion);
    }

    private void enviarSMS(String msg){
        System.out.printf("Enviando mensaje desde sms: " + msg);
    }

    @Override
    public void enviar(String msg){
        super.enviar(msg);
        this.enviarSMS(msg);
    }
}
