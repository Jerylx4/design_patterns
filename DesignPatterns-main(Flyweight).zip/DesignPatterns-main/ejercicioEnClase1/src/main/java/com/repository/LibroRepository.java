package com.repository;

import com.build.Libro;
import com.singleton.ConexionDb;

import java.sql.PreparedStatement;
import java.sql.Connection;

public class LibroRepository {

    public void insertar(Libro libro) {

        String sql = "INSERT INTO libros(id, titulo, isbn, idAutor) VALUES(?, ?, ?, ?)";

        try (Connection conn = ConexionDb.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, libro.id());
            stmt.setString(2, libro.titulo());
            stmt.setString(3, libro.isbn());
            stmt.setString(4, libro.idAutor());

            stmt.executeUpdate();

            System.out.println("Libro guardado correctamente:");
            System.out.println(libro);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
