package com.interfaces;

public interface IProductos {
}
