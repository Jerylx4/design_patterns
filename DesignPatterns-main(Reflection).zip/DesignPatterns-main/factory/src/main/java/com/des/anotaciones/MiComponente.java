package com.des.anotaciones;
//politicas a seguir y en que momentos estan habilitadas

import java.lang.annotation.*;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface MiComponente {
    String name(); //me devuelve el nombre de la clase asociada

}
