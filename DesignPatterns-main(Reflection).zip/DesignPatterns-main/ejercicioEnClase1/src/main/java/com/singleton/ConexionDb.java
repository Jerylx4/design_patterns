package com.singleton;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;

public class ConexionDb {
    private static final String URL = "jdbc:sqlite:libros.db";

    private static final HikariConfig config = new HikariConfig();
    private static final HikariDataSource ds;

    static {
        config.setJdbcUrl(URL);
        ds = new HikariDataSource(config);
    }

    private ConexionDb() {}

    public static Connection getConnection() {
        try {
            return ds.getConnection();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
