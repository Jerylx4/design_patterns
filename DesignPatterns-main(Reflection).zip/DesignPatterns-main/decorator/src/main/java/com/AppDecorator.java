package com;

import com.base.NotificacionBase;
import com.inter.Notificacion;
import com.model.NotificacionCorreo;
import com.model.NotificacionPush;
import com.model.NotificacionSMS;

import java.lang.reflect.Constructor;

public class AppDecorator {
    public static void main(String[] args) {
        String[] decoradores= {"NotificacionSMS","NotificacionCorreo","NotificacionPush", "NotificacionBase"};

        Notificacion notificacion = new NotificacionSMS(
                new NotificacionPush(
                        new NotificacionCorreo(
                                new NotificacionBase())));

        notificacion.enviar("Notificacion eviada por todos los componentes adicionales creados en ejecucion");

        Notificacion not = new NotificacionBase();

        for (String clas : decoradores) {
            try {
                Class<?> clazz = Class.forName(clas);
                Constructor<?> constructor = clazz.getConstructor(Notificacion.class);
                not = (Notificacion) constructor.newInstance(not);
            } catch (Exception e) {
                System.err.println("Error al cargar decorador: " + clas);
                e.printStackTrace();
            }
        }


        not.enviar("Nuevo mensaje dinamico");
    }

}
