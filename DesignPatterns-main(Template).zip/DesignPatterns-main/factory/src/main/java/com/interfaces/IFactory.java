package com.interfaces;

import com.implementaciones.Tipos;

public interface IFactory <T extends IProductos> {
    //IProductos createFactory(Tipos tipo);
    T createFactory(Class<T> tipo);
}
