package com.des.modelos;

import com.des.anotaciones.MiComponente;

@MiComponente(name = "proxy")

public class ProxyFisico implements Computadoras{
    {
        System.out.println("PROXY AKSHDIUHAISOFNÑ");
    }
}
