package com.inter;

public interface IEmpleado {
    void assignSkill(String skill);
    void task();
}
