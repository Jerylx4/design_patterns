package com.impl;

import com.inter.IEmpleado;

import java.util.HashMap;

public class EmpleadoFabrica {
    private static HashMap<String, IEmpleado> m = new HashMap<String, IEmpleado>();

    public static IEmpleado getEmpleado(String tipo){
        IEmpleado e = null;
        if(m.get(tipo) != null){
            e = m.get(tipo);
        } else {
            switch (tipo) {
                case "Desarrollador":
                    e = new Desarrollador();
                    break;
                case "Tester":
                    e = new Tester();
                    break;
                    default:
                        System.out.println("No se encontro el tipo de empleado.");
            }
            m.put(tipo, e);
        }
        return e;
    }
}
