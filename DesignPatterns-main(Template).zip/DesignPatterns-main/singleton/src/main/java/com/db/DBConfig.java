package com.db;

import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DBConfig {
	private HikariConfig config = new HikariConfig();
	private HikariDataSource dataSource;
	{
		config.setJdbcUrl("jdbc:sqlite:Patrones.db");
		config.setUsername("sa");
		config.setPassword("");
		config.setConnectionTimeout(1000);
		dataSource = new HikariDataSource(config);//se le pasa todo los config
		//devuelve una conexión a una base de datos
		
	}
	public Connection getConnection() {
		try {
			System.out.println("Conectando");
			return dataSource.getConnection();
		}catch(SQLException  e) {
			throw new RuntimeException(e);
			
		}
	}


	
    //ejemplo


}
