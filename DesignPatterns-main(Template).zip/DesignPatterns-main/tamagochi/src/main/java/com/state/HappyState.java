package com.state;

import com.model.Tamagotchi;
import com.strategy.IComidaStrategy;

@TamagotchiState("HAPPY")
public class HappyState implements IState{

    @Override
    public void onActividad(Tamagotchi t) {
        System.out.printf("Estoy feliz vamos a jugar");
        t.setState("SLEEPING");
    }

    @Override
    public void onComer(Tamagotchi t, IComidaStrategy s) {
        System.out.println("No tengo hambre, estoy feliz");
    }

    @Override
    public void onDormir(Tamagotchi t) {
        System.out.println("No quiero dormir, estoy feliz");
    }

    @Override
    public void onDescanso(Tamagotchi t) {
        System.out.println("No quiero descansar, s}estoy feliz");
    }
}
