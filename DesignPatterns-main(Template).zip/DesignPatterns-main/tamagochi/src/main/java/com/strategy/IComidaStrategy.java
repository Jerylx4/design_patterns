package com.strategy;

public interface IComidaStrategy {
    int feed();
}
