package com.model;

import com.inter.Decorador;
import com.inter.INotificacion;
@Decorador("push")
public class NotificacionPush extends NotificacionDecorador {
    public NotificacionPush(INotificacion notificacion) {
        super(notificacion);
    }

    private void enviarPush(String msg){
        System.out.printf("Enviando mensaje desde push: " + msg);
    }

    @Override
    public void enviar(String msg){
        super.enviar(msg);
        this.enviarPush(msg);
    }
}
