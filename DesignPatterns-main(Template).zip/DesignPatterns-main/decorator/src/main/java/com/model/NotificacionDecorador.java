package com.model;

import com.inter.INotificacion;

public abstract class NotificacionDecorador implements INotificacion {
   protected  INotificacion notificacion;
   public NotificacionDecorador(INotificacion notificacion){
       this.notificacion = notificacion;
   }

    @Override
    public void enviar(String msg) {
        notificacion.enviar("");
    }
}
