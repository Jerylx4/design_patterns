package com.model;

import com.inter.Decorador;
import com.inter.INotificacion;
@Decorador("correo")

public class NotificacionCorreo extends NotificacionDecorador{
    public NotificacionCorreo(INotificacion notificacion) {
        super(notificacion);
    }

    private void enviarCorreo(String msg){
        System.out.printf("Enviando mensaje desde correo: " + msg);
    }

    @Override
    public void enviar(String msg){
        super.enviar(msg);
        this.enviarCorreo(msg);
    }
}
