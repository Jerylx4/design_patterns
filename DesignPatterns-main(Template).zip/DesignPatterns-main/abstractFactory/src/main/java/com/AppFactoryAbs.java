package com;

import com.impl.ActionMovieFactory;
import com.impl.ComedyMovieFactory;
import com.inter.IDisneyMovie;
import com.inter.IWarnerMovie;

public class AppFactoryAbs {
    public static void main(String[] args) {
        ActionMovieFactory action = new ActionMovieFactory();
        ComedyMovieFactory comedy = new ComedyMovieFactory();
        System.out.println("Peliculas de accion disponibles");
        IWarnerMovie wAct = action.getWarnerMovie();
        IDisneyMovie dAct = action.getDisneyMovie();
        System.out.println(wAct.movieName());
        System.out.println(dAct.movieName());
        System.out.println("Peliculas de comedia disponibles");
        IWarnerMovie wCom = comedy.getWarnerMovie();
        IDisneyMovie dCom = comedy.getDisneyMovie();
        System.out.println(wCom.movieName());
        System.out.println(dCom.movieName());

    }
}
