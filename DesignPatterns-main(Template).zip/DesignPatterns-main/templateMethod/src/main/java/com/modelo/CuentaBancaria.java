package com.modelo;

public abstract class CuentaBancaria {
    private String cuenta;
    private int saldo;

    public CuentaBancaria(String cuenta, int saldo) {
        this.cuenta = cuenta;
        this.saldo = saldo;
    }

    public abstract void confirmar();

    private void retirar(int valor){
        if(valor <= this.saldo - 5){
            this.saldo -= valor;
        } else {
            System.out.println("Saldo insuficiente, no se puede realizar la transaccion");
        }
    }

    private void depositar(int valor){
        this.saldo += valor;
    }

    private void consultarSaldo(){
        System.out.println("Su saldo actual de la cuenta: "+ this.cuenta+ " es: " + this.saldo);
    }

    protected void auditoria(){
        System.out.println("Se ha almacenado en memoria la transaccion realizada de la cuenta: "+this.cuenta);
    }

    public void procesar(String c, int valor, int tipo){
        confirmar();
        switch (tipo){
            case 1:
                depositar(valor);
                break;
            case 2:
                retirar(valor);
                break;
            case 3:
                consultarSaldo();
                break;
            default:
                System.out.println("Opcion no valida");
        }
        auditoria();
    }

    public String getCuenta() {
        return cuenta;
    }
}
